package com.lms.model;

public enum BorrowStatus {
    PENDING,
    ACCEPTED,
    RETURNED,
    REJECTED,
    REQUESTED
}
